HEX_ALPHABET = "0123456789ABCDEF"

PATH = "  "


def color(x: int, y: int, col: int) -> None:
    print(f"\x1b[{y};{x}H\x1b[{col}m  \x1b[0m", end="", flush=True)


def path_str(color: int = 0, middle: str = PATH) -> str:
    return f"\033[{color}m{middle}\033[0m"


def wall_str(color: int, middle: str) -> str:
    return f"\033[{color}m{middle}\033[0m"


def draw_horizontal(row: str, col: int = 44) -> None:
    for cell in row:
        north: bool = bool(HEX_ALPHABET.index(cell) & 0x1)
        west: bool = bool(HEX_ALPHABET.index(cell) & 0x8)
        n: int = 3
        if west:
            print(wall_str(col, '  '), end='')
            n = 2
        print(wall_str(col, '  ') * n if north else path_str() * n, end="")
    print(wall_str(col, '  '))


def draw_raw(row: str, col: int = 44) -> None:
    draw_horizontal(row, col)
    for cell in row:
        west: bool = bool(HEX_ALPHABET.index(cell) & 0x8)
        print(wall_str(col, '  ') if west else path_str(), end='')
        print(path_str() * 2, end="")
    print(wall_str(col, '  '))

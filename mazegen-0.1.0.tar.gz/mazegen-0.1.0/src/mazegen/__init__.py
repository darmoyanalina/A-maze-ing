from .amazing_class import Config, MazeGenerator, Cell

__all__ = ["Config", "MazeGenerator", "Cell"]

import numpy as np
from typing import Any
import random
from pydantic import BaseModel, Field, model_validator
from .visualize import draw_raw, wall_str, HEX_ALPHABET, path_str, color
import os
from queue import Queue
from operator import sub
import time


def clear_terminal() -> None:
    """Clears the terminal screen so the maze can be redrawn in place."""
    os.system('clear')


class Config(BaseModel):
    """Configuration settings and boundary
    validation rules for maze generation.

    This data model defines the structural
    constraints, entry/exit points,
    and generation behaviors required by the maze engine, using automated
    type checking and post-initialization integrity verification.

    Attributes:
        HEIGHT: The total number of rows
        in the maze grid. Must be greater than 1.
        WIDTH: The total number of columns
        in the maze grid. Must be greater than 1.
        ENTRY: A coordinate pair (row, column)
        designating the maze entrance.
        EXIT: A coordinate pair (row, column)
        designating the maze exit.
        SEED: An optional positive integer
        to initialize the random number
            generator for reproducible layouts. Defaults to None.
        OUTPUT_FILE: The target file path
        string where the generated maze asset
            will be saved.
        PERFECT: A boolean flag indicating
        whether the maze must feature exactly
            one unique solution path without any loops.
    """
    HEIGHT: int = Field(gt=1)
    WIDTH: int = Field(gt=1)
    ENTRY: tuple[int, int]
    EXIT: tuple[int, int]
    SEED: int | None = Field(default=None, gt=0)
    OUTPUT_FILE: str
    PERFECT: bool

    @model_validator(mode='after')
    def validation(self) -> "Config":
        if self.ENTRY[0] < 0 or self.ENTRY[0] >= self.WIDTH:
            raise ValueError
        if self.ENTRY[1] < 0 or self.ENTRY[1] >= self.HEIGHT:
            raise ValueError
        if self.EXIT[0] < 0 or self.EXIT[0] >= self.WIDTH:
            raise ValueError
        if self.EXIT[1] < 0 or self.EXIT[1] >= self.HEIGHT:
            raise ValueError
        if self.ENTRY == self.EXIT:
            raise ValueError
        return self


class Cell:
    """Represents a single coordinate
    point and exploration state within the maze grid.

    Tracks structural coordinates
    and visitation status to assist traversal and
    pathfinding tracking algorithms.

    Attributes:
        x: The horizontal column index of the cell.
        y: The vertical row index of the cell.
        visited: A boolean flag indicating
        whether the cell has been explored or
            included in a structural layout. Defaults to False.
    """

    def __init__(self, x: int, y: int) -> None:
        self.x: int = x
        self.y: int = y
        self.visited: bool = False


class MazeGenerator:
    """Generates, solves, visualizes, and exports rectangular mazes.

    This class manages maze generation
    using randomized depth-first search,
    supports breadth-first search pathfinding, renders mazes in the terminal,
    and writes maze data to an output file.

    Attributes:
        conf: Configuration settings controlling maze dimensions, entry and
            exit points, output location, and generation options.
        maze: A NumPy array storing the hexadecimal wall encoding for each
            maze cell.
        cells: A two-dimensional grid of `Cell` objects representing the maze.
        stack: Working stack used during maze generation.
        queue: Queue used during breadth-first search pathfinding.
        family_tree: Maps each visited cell to its predecessor during
            pathfinding to reconstruct the final path.
    """

    def __init__(self, conf: Config) -> None:
        self.conf: Config = conf
        self.height: int = conf.HEIGHT
        self.width: int = conf.WIDTH
        self.output_file: str = conf.OUTPUT_FILE
        self.maze: np.ndarray[Any, Any] = np.full(
            (self.height, self.width), 'F')
        self.cells: list[list[Cell]] = [
            [Cell(x, y) for x in range(self.width)]
            for y in range(self.height)]
        self.stack: list[Cell] = [self.cells[0][0]]
        self.counter: int = 0
        self.queue: Queue[Cell] = Queue()
        self.family_tree: dict[Cell, Cell | None] = {}
        self._fourty_two_pattern: list[str] = [
            "1000111",
            "1000001",
            "1110111",
            "0010100",
            "0010111"
        ]

    def visualize(self, filename: str, color: int = 44) -> None:
        """Visualizes the maze in the terminal based on a file's contents.

        Reads a hexadecimal or formatted maze
        representation from a specified
        file, parses the grid structure, and renders it directly to the
        standard output using terminal styling utilities.

        Args:
            filename: The path to the text
            file containing the maze data.

        Raises:
            FileNotFoundError: If the specified file does not exist.
            ValueError: If characters in the
            file are not found in HEX_ALPHABET.
        """
        matrix: list[str] = []
        with open(filename, 'r') as file:
            for line in file:
                if line.startswith('\n'):
                    break
                matrix.append(line.strip())
        for row in matrix:
            draw_raw(row, color)
        for cell in matrix[-1]:
            south: bool = bool(HEX_ALPHABET.index(cell) & 0x4)
            print(wall_str(color, '  ') * 3
                  if south else path_str() * 3, end="")
        print(wall_str(color, '  '), end="")
        print()

    def draw_path(self, path: list[Cell]) -> None:
        """Draws the solution path on the maze in the terminal.

        Clears the terminal, redraws the maze,
        and highlights the cells in
        `path`. The starting cell, intermediate cells, and final cell are
        displayed using different colors to
        distinguish the route. The terminal
        cursor is repositioned below the maze after drawing.

        Args:
            path: A sequence of `Cell` objects
            representing the path from the
                maze entrance to the exit.
        """
        clear_terminal()
        self.visualize(self.output_file)
        color((path[0].x*6)+4, (path[0].y*2)+2, 41)
        for cell in path[1:]:
            color((cell.x*6)+4, (cell.y*2)+2, 45)
        color((path[-1].x*6)+4, (path[-1].y*2)+2, 43)
        print(f"\x1b[{len(self.cells)*2 + 2};1H", end="", flush=True)

    def _fourty_two(self) -> bool:
        """Marks the cells of the '42' pattern as visited, if it fits the grid.

        Computes the centered placement of the
        fixed '42' ASCII-art pattern
        within the maze bounds and, if it fits without exceeding the grid,
        marks each corresponding cell's `visited` flag according to the
        pattern's '1' characters. Intended to be used as a pre-carved shape
        that generation logic and imperfect-maze
        post-processing can react to.

        Returns:
            True if the pattern fit within the
            grid and was applied, False if
            there was not enough space and no
            cells were marked.
        """
        pattern: list[str] = self._fourty_two_pattern
        pattern_h: int = len(pattern)
        pattern_w: int = len(pattern[0])

        origin_y: int = self.height // 2 - pattern_h // 2
        origin_x: int = self.width // 2 - pattern_w // 2

        fits: bool = (
            origin_y >= 0 and origin_x >= 0
            and origin_y + pattern_h < self.height
            and origin_x + pattern_w < self.width
        )
        if not fits:
            print("[KO] - Not enough space for 42 pattern")
            return fits

        for j, row in enumerate(pattern):
            for i, char in enumerate(row):
                if char == '1':
                    self.cells[origin_y + j][origin_x + i].visited = True
        return fits

    def _break_wall(self, cell: Cell, target_wall: str) -> None:
        """Removes the wall between a cell
        and its neighbour in a given direction.

        Updates the hexadecimal wall
        encoding of both `cell` and the adjacent
        cell in `target_wall`'s
        direction so that the wall between them is
        considered open in both cells' encodings.

        Args:
            cell: The cell whose wall should be broken.
            target_wall: The direction of the wall to break. One of
                'North', 'South', 'East', 'West'.
        """
        directions: dict[str, tuple[int, int]] = {
            'South': (0, 1), 'North': (0, -1), 'East': (1, 0), 'West': (-1, 0)}
        walls: dict[str, int] = {'South': 0xb,
                                 'North': 0xe, 'East': 0xd, 'West': 0x7}
        op: dict[str, str] = {'South': 'North',
                              'North': 'South', 'East': 'West', 'West': 'East'}
        cur: Any = HEX_ALPHABET.index(self.maze[cell.y][cell.x])
        self.maze[cell.y][cell.x] = HEX_ALPHABET[cur & walls[target_wall]]
        new_y: int = cell.y + directions[target_wall][1]
        new_x: int = cell.x + directions[target_wall][0]
        opposite: Any = HEX_ALPHABET.index(self.maze[new_y][new_x])
        self.maze[new_y][new_x] = HEX_ALPHABET[opposite &
                                               walls[op[target_wall]]]

    def _find_neigh(self, cell: Cell) -> Any:
        """Finds the unvisited neighbours of a cell and marks it as visited.

        Also pushes `cell` onto
        `self.stack` if it had not yet been visited,
        supporting the iterative depth-first generation walk.

        Args:
            cell: The cell whose neighbours should be examined.

        Returns:
            A mapping from
            direction name ('North', 'South', 'East', 'West')
            to that neighbour's (x, y) coordinates if it exists and is
            unvisited, or None if there
            is no neighbour in that direction or
            it has already been visited.
        """
        current_cell: Cell = cell
        neighbours: dict[str, tuple[int, int] | None] = {}
        directions: dict[str, tuple[int, int]] = {
            'South': (0, 1), 'North': (0, -1), 'East': (1, 0), 'West': (-1, 0)}

        for direction in directions:
            nx: int = current_cell.x + directions[direction][0]
            ny: int = current_cell.y + directions[direction][1]
            if ((nx >= 0 and nx < self.width) and
                    (ny >= 0 and ny < self.height)):
                if self.cells[ny][nx].visited is False:
                    neighbours[direction] = (nx, ny)
            else:
                neighbours[direction] = None
        if not current_cell.visited:
            self.stack.append(current_cell)
        current_cell.visited = True
        return neighbours

    def _unvisit(self) -> None:
        """Resets the `visited` flag to False for every cell in the grid."""
        for row in self.cells:
            for item in row:
                item.visited = False

    def _clear42(self) -> None:
        """Opens a passage through the centre of the '42' pattern.

        Breaks the North/South walls of
        the two cells at the vertical centre
        of the pattern so that an
        imperfect maze does not leave the '42'
        shape sealed off from the rest of the maze.
        """
        origin_y: int = self.height // 2
        origin_x: int = self.width // 2
        self._break_wall(self.cells[origin_y][origin_x], "North")
        self._break_wall(self.cells[origin_y][origin_x], "South")
        self._break_wall(self.cells[origin_y+2][origin_x], "North")
        self._break_wall(self.cells[origin_y+2][origin_x], "South")

    def _imperfectiate(self) -> None:
        """Breaks additional walls to
        turn a perfect maze into an imperfect one.

        Identifies cells left unvisited by generation (including any '42'
        pattern cells), then repeatedly breaks a wall from each such cell
        toward an unvisited neighbour until no more walls can be broken. This
        introduces loops and alternate routes. If the '42' pattern was
        successfully placed and the maze is not configured as PERFECT, also
        opens a passage through its centre via `_clear42`.
        """
        self._unvisit()
        has_42: bool = self._fourty_two()
        walls: list[Cell] = []
        directions: dict[str, tuple[int, int]] = {
            'South': (0, 1), 'North': (0, -1), 'East': (1, 0), 'West': (-1, 0)}
        openings: dict[str, int] = {'South': 0xb,
                                    'North': 0xe, 'East': 0xd, 'West': 0x7}
        for row in self.cells:
            for cell in row:
                if not cell.visited:
                    walls.append(cell)
        changed: bool = True
        while changed:
            changed = False
            for wall in walls:
                for open in openings:
                    if int(self.maze[wall.y][wall.x], 16) == openings[open]:
                        for direction in directions:
                            if direction == open:
                                continue
                            new_y: int = wall.y + directions[direction][1]
                            new_x: int = wall.x + directions[direction][0]
                            if (0 <= new_y < len(self.cells)
                                and 0 <= new_x < len(self.cells[0])
                                    and not self.cells[new_y][new_x].visited):
                                self._break_wall(wall, direction)
                                changed = True
                                break

        if has_42 and not self.conf.PERFECT:
            self._clear42()

    def _choose_start(self) -> Cell:
        """Picks a uniformly random cell
        to use as a generation starting point.

        Returns:
            A randomly selected `Cell` from the grid.
        """
        return self.cells[random.randint(
            0, self.height - 1)][random.randint(0, self.width - 1)]

    def generate(self) -> None:
        """Generates a randomized maze

        layout and visualizes the construction process.

        Resets the maze state, applies custom
        structural patterns, and selects an
        unvisited starting cell. It uses a
        randomized depth-first search algorithm
        to carve paths through the grid while
        dynamically rendering the progression
        to the terminal display. If the
        configuration specifies an imperfect maze,
        it breaks additional walls to create
        loops and alternative paths before
        the final rendering.
        """
        self._unvisit()
        self._fourty_two()
        current_cell: Cell = self._choose_start()
        i: int = 1
        while current_cell.visited:
            if self.conf.SEED:
                random.seed(self.conf.SEED + i)
            current_cell = self._choose_start()
            i += 1
        while len(self.stack) > 0:
            neighbours: dict[str, tuple[int, int] |
                             None] = self._find_neigh(current_cell)
            neigh_list: list[str] = [
                neigh for neigh in neighbours if (neighbours[neigh]
                                                  is not None)]
            neighbour: str | None = random.choice(
                neigh_list) if len(neigh_list) else None
            if neighbour:
                coords: tuple[int, int] | None = neighbours[neighbour]
                if coords is not None:
                    self._break_wall(current_cell, neighbour)
                    self.output()
                    clear_terminal()
                    self.visualize(self.output_file)
                    current_cell = self.cells[coords[1]][coords[0]]
            else:
                current_cell = self.stack.pop()
        if not self.conf.PERFECT:
            self._imperfectiate()
            self.output()
            clear_terminal()
            self.visualize(self.output_file)

    def _route(self, cell: Cell) -> None:
        """Enqueues the unvisited, reachable neighbours of a cell for BFS.

        For each direction without a wall in `cell`'s encoding, if the
        neighbouring cell exists and has not yet been visited, marks it
        visited, records `cell` as its
          predecessor in `self.family_tree`, and
        adds it to `self.queue` for later processing.

        Args:
            cell: The cell currently being expanded during breadth-first
                pathfinding.
        """
        walls: dict[str, int] = {'North': 0x1,
                                 'East': 0x2, 'South': 0x4, 'West': 0x8}
        directions: dict[str, tuple[int, int]] = {
            'South': (0, 1), 'North': (0, -1), 'East': (1, 0), 'West': (-1, 0)}
        for wall in walls:
            cell_let: int = HEX_ALPHABET.index(self.maze[cell.y][cell.x])
            new_y: int = cell.y + directions[wall][1]
            new_x: int = cell.x + directions[wall][0]
            if ((new_x >= 0 and new_x < self.width)
                    and (new_y >= 0 and new_y < self.height)):
                if (not (walls[wall] & cell_let)
                        and not self.cells[new_y][new_x].visited):
                    self.queue.put(self.cells[new_y][new_x])
                    self.family_tree[self.cells[new_y][new_x]] = cell
                    self.cells[new_y][new_x].visited = True

    def _get_path(self, path: list[Cell]) -> list[str]:
        """Converts a sequence of cells into directional step letters.

        Args:
            path: An ordered list of cells from entry to exit.

        Returns:
            A list of single-character
            direction codes ('N', 'S', 'E', 'W')
            describing the step taken
            between each consecutive pair of cells
            in `path`.
        """
        directions: dict[str, tuple[int, int]] = {
            'S': (1, 0), 'N': (-1, 0), 'E': (0, 1), 'W': (0, -1)}
        path_let: list[str] = []
        for i in range(1, len(path)):
            for dir in directions:
                if tuple(map(sub, (path[i].y, path[i].x),
                             (path[i-1].y,
                              path[i-1].x))) == directions[dir]:
                    path_let.append(dir)
        return path_let

    def _visit_path(self, path: list[Cell]) -> None:
        """Marks only the cells in the solved path as visited.

        Resets all cells' `visited` flags and then sets it to True for each
        cell in `path`, so the solution route can be distinguished from the
        rest of the maze.

        Args:
            path: The solved path from entry to exit.
        """
        self._unvisit()
        for cell in path:
            cell.visited = True

    def find_path(self) -> list[Cell]:
        """Finds and visualizes a path
        from the configured entrance to the exit.

        Resets the visitation state of the
        maze and uses a breadth-first search
        to locate the exit from the
        designated starting cell. As the path is
        reconstructed backward from
        the exit to the entrance, the drawing interface
        is updated incrementally to
        visualize the progression. The final path is
        then saved to the output
        destination and marked as visited.

        Returns:
            A list of `Cell` objects
            representing the sequential steps taken to
            traverse the maze from the entrance to the exit.
        """
        self._unvisit()
        entry: Cell = self.cells[self.conf.ENTRY[0]][self.conf.ENTRY[1]]
        exit: Cell = self.cells[self.conf.EXIT[0]][self.conf.EXIT[1]]
        path: list[Cell] = []
        entry.visited = True
        self.queue.put(entry)
        self.family_tree[entry] = None
        got: Cell = self.queue.get()
        while self.queue and got is not exit:
            self._route(got)
            got = self.queue.get()
        if got is exit:
            path.append(got)
        cell: Cell | None = got
        while cell is not entry:
            if cell:
                path.append(self.family_tree[cell])  # type: ignore
                time.sleep(0.05)
                self.draw_path(path)
                cell = self.family_tree[cell]
        path.reverse()
        self.output(self._get_path(path))
        self._visit_path(path)
        self.draw_path(path)
        return path

    def output(self, path: list[str] | None = None) -> None:
        """Writes the current maze layout
        and optional solution details to a file.

        Outputs the raw character grid line
        by line to the configured output path.
        Beneath the layout grid, it appends
        the entry and exit coordinates stripped
        of formatting. If a solved path
        sequence is provided, the abbreviated
        directional steps are joined and
        appended to the final line of the file.

        Args:
            path: An optional list of
            strings representing the directional steps
                (e.g., 'N', 'S', 'E', 'W')
                that solve the maze. Defaults to None.
        """
        with open(self.output_file, 'w') as out:
            for row in self.maze:
                for column in row:
                    out.write(column)
                out.write("\n")
            out.write(f'\n{str(self.conf.ENTRY).strip("()")}\n')
            out.write(str(self.conf.EXIT).strip("()"))
            if path:
                out.write(f'\n{"".join([item for item in path])}')
